/*
 * CacheAssociatif.java
 *
 * Created on 05 janvier 2017
 *
 */



/**
 *
 * @author nicolas
 */
import java.util.*;
import java.io.*;


/**
 *
 * @author nicolas
 */
public class CacheAssociatif {
    private int nbEntrees; // nombre d'entrees du cache
    private int n; // nombre de bits pour d�signer une ligne du cache
    private int p; // nombre de bits pour le deplacement dans le bloc
    private int nbLignes; //=2**n : nombre de lignes du cache
    private int[][] cache;
    private boolean[][] modifie;
    private boolean[][] valide;
    private int[][] lru;
    
    private int succes=0;
    private int echecs=0;
    private int writeThrough=0;
    private int writeBack=0;
    
    /** Creates a new instance of CacheAssociatif */
    public CacheAssociatif(int n, int p, int nbEntrees) {
        this.nbEntrees=nbEntrees;
        this.n=n;
        this.p=p;
        nbLignes=(int)Math.pow(2,n);
        cache = new int[nbLignes][nbEntrees];
        modifie = new boolean[nbLignes][nbEntrees];
        valide = new boolean[nbLignes][nbEntrees];
        lru = new int[nbLignes][nbEntrees];
        for(int i=0; i<nbLignes; i++){
            for(int j=0; j<nbEntrees; j++){
                modifie[i][j]=false;
                valide[i][j]=false;
                lru[i][j]=j+1;
            }
        }
        
    }
    
    public void lecture(int adresse){
        
        // on recupere l'etiquette
        int etiquette=adresse/(int)(Math.pow(2,n+p));
        
        // on recupere le numéro de ligne
        int ligne = (adresse%(int)(Math.pow(2,n+p)))/(int)(Math.pow(2,p));

        //on regarde si la ligne est valide et si elle contient la memoire recherchee
        boolean trouve=false;
        int entree=-1;

        while(trouve==false && entree<nbEntrees-1){
            entree++;
            if (valide[ligne][entree]==true && etiquette==cache[ligne][entree]) trouve=true;
            
        }
    
        if (trouve==true){
            succes++;
            miseAJourLRU(ligne,entree);
        }
        else {
            echecs++;
            // on cherche l'entree a� supprimer
            int k=-1;
            trouve=false;
            while (k<nbEntrees-1&&trouve==false){
                k++;
                if(lru[ligne][k]==nbEntrees)trouve=true; 
            }
            // on charge la ligne dans le cache
            if (modifie[ligne][k]){
                writeBack++;
                modifie[ligne][k]=false;
            }
            cache[ligne][k]=etiquette;
            miseAJourLRU(ligne,k);
        }
    }
    
    public void ecriture(int adresse){
        
        // on recupere l'etiquette
        int etiquette=adresse/(int)(Math.pow(2,n+p));
        
        // on recupere le numéro de ligne
        int ligne = (adresse%(int)(Math.pow(2,n+p)))/(int)(Math.pow(2,p));

        //on regarde si la ligne est valide et si elle contient la memoire recherchee
        boolean trouve=false;
        int entree=-1;

        while(trouve==false && entree<nbEntrees-1){
            entree++;
            if (valide[ligne][entree]==true && etiquette==cache[ligne][entree]) trouve=true;
            
        }
    
        if (trouve==true){
            succes++;
            writeThrough++;
            miseAJourLRU(ligne,entree);
            modifie[ligne][entree]=true;
        }
        else {
            echecs++;
            // on cherche l'entree a� supprimer
            int k=-1;
            trouve=false;
            while (k<nbEntrees-1&&trouve==false){
                k++;
                if(lru[ligne][k]==nbEntrees)trouve=true; 
            }
            // on charge la ligne dans le cache
            if (modifie[ligne][k]){
                writeBack++;
                modifie[ligne][k]=false;
            }
            cache[ligne][k]=etiquette;
            miseAJourLRU(ligne,k);
        }
    }
    
    public void lectureFichier(String nomFichier) throws IOException{
        
        Scanner scan=new Scanner(new File (nomFichier));
        // on lit la liste des adresses
        while (scan.hasNext()){
            Scanner scan2=new Scanner(scan.nextLine());
            scan2.useDelimiter(":");
            int adr=scan2.nextInt();
            if (scan2.next().equals("R"))
                lecture(adr);
            else
                ecriture(adr);
        }

        // on compte les writeback résiduels
        for(int i=0; i<nbLignes; i++){
            for(int j=0; j<nbEntrees; j++){
                if (modifie[i][j]) writeBack++;
            }
        }
    }
    void miseAJourLRU(int ligne,int entree){
        
        int max=lru[ligne][entree];
        valide[ligne][entree]=true;
        lru[ligne][entree]=1;
        for(int i=0;i<nbEntrees;i++){
            if (i!=entree && lru[ligne][i]<max)
                lru[ligne][i]++;
        }
        
    }


    @Override
    public String toString(){
        String ret;
        float tps = (5*succes+50*echecs)/(float)(echecs+succes); //tmpe d'accès moyen
        ret="writeback = "+writeBack+"\nwrite through = "+writeThrough+"\nnbLignes = "+nbLignes+"\nNbEntrees = "+nbEntrees+"\nSucces = "+succes+"\nechecs = "+echecs+"\ntemps moyen d'acces = "+tps;
        
        return ret;
        
    }  
    
}
