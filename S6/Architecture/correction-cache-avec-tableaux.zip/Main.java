/*
 * Main.java
 *
 * Created on 26 mars 2007, 10:09
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */



import java.io.IOException;

/**
 *
 * @author nicolas
 */
public class Main {
    
    /** Creates a new instance of Main */
    public Main() {
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        CacheAssociatif cache1=new CacheAssociatif(3,5,2);
        try { 
            cache1.lectureFichier("matrice10.txt");
        } 
        catch (IOException ex) {
            ex.printStackTrace();
        }
        
        System.out.println(cache1);
        
        
    }
    
}
