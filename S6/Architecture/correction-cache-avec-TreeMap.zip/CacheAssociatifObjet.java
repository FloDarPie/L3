import java.io.File;
import java.io.FileNotFoundException;
import java.util.HashMap;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeMap;


public class CacheAssociatifObjet {

	private int tailleBloc;
	private int nbLigne;
	private int echecs;
	private int nbEntrees; 
	public int getEchecs() {
		return echecs;
	}

	public void setEchecs(int echecs) {
		this.echecs = echecs;
	}

	public int getSucces() {
		return succes;
	}

	public void setSucces(int succes) {
		this.succes = succes;
	}

	private int succes;
	private TreeMap<Integer,Integer> etiquette;
	private TreeMap<Integer,Integer>[] cache;

	public CacheAssociatifObjet(int tailleBloc, int nbLigne, int nbEntrees) {
		super();
		echecs = 0;
		succes = 0;
		// initialisation du cache
		cache = new TreeMap [(int) Math.pow(2, nbLigne)];
		this.tailleBloc = tailleBloc;
		this.nbLigne = nbLigne;
		this.nbEntrees = nbEntrees;
		// npo d'initialiser les treemap a chaque ligne
		for(int i=0; i<cache.length;i++){
			cache[i] = new TreeMap<Integer,Integer>();
		}

	}

	public void remplissage() throws FileNotFoundException {
		// Lecture du fichier contenant les adresses en base 10
		File f = new File("matrice10.txt");
		Scanner sc = new Scanner(f);
		int compteur = 0;
		while (sc.hasNextLine()) {
			compteur++;
			// recup�re chaque adresse
			int adr = Integer.parseInt(sc.nextLine().split(":")[0]);
			//System.out.println("adresse = " + adr);
			
			// enl�ve le deplacement � l'adresse
			adr = adr / (int) tailleBloc;
			
			// recup�re les n derniers bit
			int ligne = adr % (int) Math.pow(2, nbLigne);
			//System.out.println("ligne = " + ligne);
			
			// enleve les n derniers bit
			int etiquette = adr / (int) Math.pow(2, nbLigne);
			//System.out.println("etiquette = " + etiquette);
			for(int i = 0;i<nbEntrees;i++){
				if(cache[ligne] != null){
					System.out.println("cache[ligne] : " + cache[ligne]);
				}
			}
			// si la valeur � la ligne est �gale � l'etiquette
			if (cache[ligne].containsValue(etiquette)) {
				// mis a jour du compteur 
				Set<Integer> keys = cache[ligne].keySet();
				int cle = 0;
				// parcours de toutes les cle de la treeMap
				for(Integer key : keys){
					// si il y en a une qui correspond
					if(cache[ligne].get(key) == etiquette ){
						cle = key;
					}
				}
				// on la supprime 
				cache[ligne].remove(cle);
				// puis on la met a jour
				cache[ligne].put(compteur,etiquette);
				// alors c'est un succes elle est presente dans le cache
				succes++;
				
			} else {
				// si echecs alors on remplace la premiere valeur de la TreeMap
				echecs++;
				
				// si il reste des entr�es
				if(cache[ligne].size() < nbEntrees){
					// on l'ajoute directement � la fin de la TreeMap
					cache[ligne].put(compteur, etiquette);
				} else {
					// sinon on �crase l'�tiquette � la ligne correspondante 
					// et la ou la valeur de LRU (ici compteur) est la plus petite
					System.out.println("1) = "+cache[ligne]);
					cache[ligne].remove(cache[ligne].firstEntry().getKey());
					cache[ligne].put(compteur, etiquette);
					System.out.println("2) = "+cache[ligne]);
				}
			}
			
			
			
		}
	}

	/**
	* Privil�gi� les classes de test plut�t qu'un main dans la classe objet
	*/
	public static void main(String[] args) throws FileNotFoundException {
		int n;
		// saisie de la taille du cache nb de ligne du cache
				
//		Scanner entree = new Scanner(System.in);
//		System.out.println("Entrer la taille du cache :");
//		System.out.print("n= ");
//		n = entree.nextInt();
		CacheAssociatifObjet cache = new CacheAssociatifObjet(32,4,2);
		cache.remplissage();
		System.out.println("nb Echecs = "+ cache.getEchecs());
		System.out.println("nb succes = "+ cache.getSucces());
	}
}
