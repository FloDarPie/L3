import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class CacheDirectObjet {

	private int tailleBloc;
	private int nbLigne;
	private int echecs;
	private int tempsMoyen;
	public int getEchecs() {
		return echecs;
	}

	public int getSucces() {
		return succes;
	}
	
	public int getTempsMoyen(){
		return tempsMoyen;
	}


	private int succes;
	private int[] cache;

	public CacheDirectObjet(int tailleBloc, int nbLigne) {
		super();
		// initialisation du cache
		cache = new int[(int) Math.pow(2, nbLigne)];
		// a -1 car l'etiquette 0 existe
		for (int i = 0; i < cache.length; i++) {
			cache[i] = -1;
		}
		;
		this.tailleBloc = tailleBloc;
		this.nbLigne = nbLigne;

	}

	public void remplissage() throws FileNotFoundException {
		// Lecture du fichier contenant les adresses en base 10
		File f = new File("matrice10.txt");
		Scanner sc = new Scanner(f);
		while (sc.hasNextLine()) {
			// recup�re chaque adresse
			int adr = Integer.parseInt(sc.nextLine().split(":")[0]);
			System.out.println("adresse = " + adr);

			// enl�ve le deplacement � l'adresse
			adr = adr / (int) tailleBloc;

			// recup�re les n derniers bit
			int ligne = adr % (int) Math.pow(2, nbLigne);
			System.out.println("ligne = " + ligne);

			// enleve les n derniers bit
			int etiquette = adr / (int) Math.pow(2, nbLigne);
			System.out.println("etiquette = " + etiquette);
			System.out.println("cache[ligne]" + cache[ligne]);
			
			// si la valeur � la ligne est l'etiquette
			if (cache[ligne] == etiquette) {
				// alors c'est un succes elle est presente dans le cache
				succes++;	

			} else {
				// sinon c'est un echec
				echecs++;
				// et on �crase l'�tiquette � la ligne
				cache[ligne] = etiquette;

			}
		}
	}

	public static void main(String[] args) throws FileNotFoundException {
		int n;
		// saisie de la taille du cache nb de ligne du cache
				
		Scanner entree = new Scanner(System.in);
		System.out.println("Entrer la taille du cache :");
		System.out.print("n= ");
		n = entree.nextInt();
		CacheDirectObjet cache = new CacheDirectObjet(32,n);
		cache.remplissage();
		System.out.println("nb Echecs = "+ cache.getEchecs());
		System.out.println("nb succes = "+ cache.getSucces());
		System.out.println("temps moyen =" + (cache.getSucces() * 5 + cache.getEchecs() * 55 )/ 4400 + " nanoseconde");
	}
}
